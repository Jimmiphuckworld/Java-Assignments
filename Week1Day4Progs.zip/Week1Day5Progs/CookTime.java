import FormatIO.*;

public class CookTime {

    public static void main (String [] args) {

	// input cooking time parameters
        Console con = new Console("Cooking Helper");
	con.print("Enter mins per kg: ");
	int minsPerKg = con.readInt();
	con.print("Enter extra mins:  ");
	int extraMins = con.readInt();
	con.print("Enter meat weight in kg: ");
	double weight = con.readDouble();

	// input finish time
	con.print("Enter finish time using 24 hour clock: ");
	int time = con.readInt();

	// calculate cooking time
	int cookTime = (int) (minsPerKg * weight + extraMins);
	int endHours = time / 100;
	int endMins  = time % 100;
	int endTotalMins = 60 * endHours + endMins;
	int startTotalMins = endTotalMins - cookTime;
	int startHours = startTotalMins / 60;
	int startMins  = startTotalMins % 60;

	// output start time
	String out = String.format("%02d%02d", startHours, startMins);
	con.print("Put meat in oven at " + out);
    }
}
