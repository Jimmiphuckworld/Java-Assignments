import FormatIO.*;

public class InputTester {

    public static void main (String [] args) {
 
        Console con = new Console();
        con.println("What is your name?");
	String name = con.readLine();
        con.println("Hello, "+name+", how are you?");

    }
}