import FormatIO.*;

public class GreetingTester {

    public static void main (String [] args) {
 
        Console con = new Console();

        FileOut fout = new FileOut("greeting.txt"); 
	fout.println("Hi Simon"); 

        con.println("File output complete.");
    }
}