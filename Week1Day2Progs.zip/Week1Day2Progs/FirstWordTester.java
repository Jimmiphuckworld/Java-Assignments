import FormatIO.*;

public class FirstWordTester {

    public static void main (String [] args) {
 
        Console con = new Console();
        FileIn fin = new FileIn();
        String word = "";
        word = fin.readWord(); 
        con.println(word);

    }
}