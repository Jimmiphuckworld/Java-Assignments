import FormatIOX.*;

public class Menu {

    private static String readFile() {
	FileIn fin = new FileIn("input.txt");
	String data = "";
	try {
	    int lineCount = 0;
	    for (;;) {
		String line = fin.readLine();
		lineCount++;
		line = lineCount + ". " + line + "\n";
		data += line;
	    }
	}
	catch (EofX e) {}
	fin.close();
	return data;
    }

    private static void saveFile(String data) {
	FileOut fout = new FileOut("output.txt");
	fout.print(data);
	fout.close();
    }

    private static String getMenuChoice(Console con, String data) {
        con.print("What next: ");
        String line = con.readLine();
        char option = line.charAt(0);
        switch (option) {
            case 'q':
            System.exit(0);
                break;
            case 's':
                saveFile(data);
                break;
            case 'r':
                data = readFile();
                break;
            case ' ':
            case '\t':
            case '\n':
                break; // ignore, user might enter newlines spaces and tabs
            default:
                con.println("Illegal option");
                break;
	}
	return data;
    }

    public static void main(String[] arg) {
	// get info from user
	String data = "";
	Console con = new Console();
        for (;;)
	    data = getMenuChoice(con, data);
    }
}
