import FormatIO.*;

public class DaysInMonth {

    private static boolean isLeap(int year) {
	return year % 4 == 0 && year % 100 != 0
	       || year % 400 == 0;
    }

    private static int daysInMonth(int month, int year) {
        switch (month) {
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;

            case 2:
                if (isLeap(year))
                    return 29;
                else
                    return 28;

            default:
                return 31;
	}
    }

    public static void main(String[] arg) {
	// get info from user
	Console con = new Console();
	con.print("Enter the month: ");
	int monthNum = con.readInt();
	con.print("Enter the year: ");
	int yearNum = con.readInt();

	// calculate number of days
	int numDays = daysInMonth(monthNum, yearNum);
	con.println("The number of days this month is "+numDays);
    }
}
