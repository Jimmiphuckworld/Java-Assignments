import FormatIO.*;

public class FormatOutput {

    public static void main(String[] arg)
    {

	Console con = new Console();

        String line = String.format("23 divided by 5 is %d remainder %d \n\n", 23/5, 23%5);

        line = line + String.format("%14s = %3d \n", "3+4*5+6", 3+4*5+6);
        line = line + String.format("%14s = %3d \n", "(3+4)*(5+6)", (3+4)*(5+6));

        line = line + String.format("%14s = %3d \n", "20/5/2", 20/5/2);
	line = line + String.format("%14s = %3d \n", "(20/5)/2", (20/5)/2);
        line = line + String.format("%14s = %3d \n", "20/(5/2)", 20/(5/2));

        line = line + String.format("%14s = %3.1f \n", "(double) (5/2)", (double) (5/2));
        line = line + String.format("%14s = %3.1f \n", "5/(double) 2", 5/(double) 2);


	con.println(line);
    }
}
