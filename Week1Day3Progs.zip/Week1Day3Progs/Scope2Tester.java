/*
 *  A program to read the radius from a file and
 *  print out the area of the circle.
 *  The file has one line with the form:
 *  	radius = <actuual radius> meters
 *  The unwanted words are read as strings but not used.
 *  The radius is read as a double.
 *  
 *  The area message is written to two Consoles and an
 *  output file called Lab2Out.txt.
 *  
 *  Author: Ron Poet - 18th Sep 2006
 */

import FormatIO.*;

public class Scope2Tester {

    public static void main(String[] arg)
    {
	String word1, word2, word3;
	double radius = 0;
	
	// create a FileIn object and read the data.
	FileIn fin = new FileIn("..\\radius.txt");

        { // useless example block - legal
            String line = fin.readLine();
        }
		
        StringIn sin = new StringIn(line);

	word1 = sin.readWord();
	word2 = sin.readWord();
	radius = sin.readDouble();
	word3 = sin.readWord();
	
	// calculate the area and output message
	// store the message in a String for efficiency
	double area = Math.PI * radius * radius;
	String message = "The area is " + area;
	
	// create the Consoles and write to them
	Console con1 = new Console("Console 1", 5, 20);
	Console con2 = new Console("Console 2", 5, 20);
	
	con1.println(message);
	con2.println(message);
	
	// create the output file and write to it
	FileOut fout = new FileOut("Lab2Out.txt");
	fout.println(message);
    }
}
