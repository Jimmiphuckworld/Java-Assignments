/*
 *  This class draws an character box in a separate Console
 *  Another Console is used for user input.
 *  It uses helper methods to draw the top/bottom and sides.
 *  A box looks like
 *  
 *  +---------+
 *  |         |
 *  +---------+
 */

import FormatIO.*;

public class Lab7Ex2 {

    public static void main(String[] arg)
    {
	// Create the user IO console
	Console con = new Console();
	
		// Loop getting box parameters
	for (;;)
	{
	    con.print("Do you want to draw a box? ");
	    String reply = con.readWord();
	    if (reply.equals("no"))
		break;

	    con.print("How many rows? ");
	    int nRows = con.readInt();
	    con.print("How many cols? ");
	    int nCols = con.readInt();
		
	    if (nRows > 0 && nCols > 0)
		drawBox(nRows, nCols);
	}
    }

    private static void drawBox(int nRows, int nCols)
    {
	Console boxCon = new Console(nRows+2, nCols+5);

	drawTop(boxCon, nCols); // top
	if (nRows == 1) // only one row
	    return;
	
	for (int i = 0; i < nRows-2; i++)
	    drawSide(boxCon, nCols); // draw all the sides

	drawTop(boxCon, nCols); // draw bottom
    }

    private static void drawTop(Console con, int n)
    {
	con.print("+");
	if (n == 1) {	// only one column
	    con.println();
	    return;
	}

	for (int i = 0; i < n - 2; i++)
	// will not do anything if n == 2
	    con.print("-");

	con.print("+");
	con.println();
    }

    private static void drawSide(Console con, int n)
    {
	con.print("|");
	if (n == 1) {	// only one column
	    con.println();
	    return;
	}

	for (int i = 0; i < n - 2; i++)
	// will not do anything if n == 2
	    con.print(" ");

	con.print("|");
	con.println();
    }
}
