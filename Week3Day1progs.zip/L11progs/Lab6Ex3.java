/*
 *  Computer chooses a number and the user has many guesses.
 *  They are told either correct, too high or too low.
 *  The user can play several games, until they say No.
 *  They are told their average score.
 */
import FormatIO.*;
import java.util.*;

public class Lab6Ex3 {

    public static void main(String[] arg) {

	// create helper objects
	Console con = new Console("Guess");
	Random rand = new Random();
	
	// remember total score and number of games
	int totalScore = 0, numGames = 0;
	
	for (;;)	// repeat games loop
	{
		// choose a random number between 0 and 9
		int num = Math.abs(rand.nextInt()) % 10;
		// System.err.println(num); // for testing
	
		// variable to count number of attempts
		int count = 0;
	
		// loop until user gets it right
		for (;;)  // loop until user guesses correctly
		{
			// get the user's guess
			con.print("Guess a number: ");
			int guess = con.readInt();
			count++;
	
			// print how they did
			if (guess == num)
			{
				con.println("CORRECT!!!, you took " + count + " guesses");
				break;	// break out loop
			}
			else if (guess > num)
				con.println("Too high");
			else
				con.println("Too low");
		}
		
		// update totals
		totalScore += count;
		numGames++;
		
		// see if should go round again
		con.print("Do you want another go? ");
		String reply = con.readWord();
		if (reply.equals("no"))
			break;	// break out loop
	}
	
	// print out average score
	con.print("Thank you for playing.  Your average was ");
	// average needs precision
	double average = (double) totalScore / numGames;
	String averageString = String.format("%6.2f",average);
	con.println(averageString);
    }
}
