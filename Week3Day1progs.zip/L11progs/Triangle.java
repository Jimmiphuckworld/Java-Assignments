import FormatIO.*;

public class Triangle {

    private static void drawRow(Console con, int nStars) {
	for (int i = 1; i <= nStars; i++)
	   con.print("*");
	con.println();
    }

    public static void main(String[] arg) {
	// get info from user
	Console con = new Console("Triangle");
	con.print("How many rows of stars?: ");
	int nRows = con.readInt();
	
	// loop through rows
	for (int i = 1; i <= nRows; i++)
		drawRow(con, i);
    }
}
